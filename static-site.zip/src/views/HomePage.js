// src/views/HomePage.js
import React from 'react';

const HomePage = () => {
  return <h1>Welcome to the Home Page</h1>;
};

export default HomePage;
