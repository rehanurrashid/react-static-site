import React, {useState} from 'react'



export default function TextForms(props) {

    const [text, setText] = useState('Enter text here');

    const handleOnClick = () => {
        console.log('handleClickUp')
        let newText = text.toUpperCase();
        setText(newText)
    }
    const handleOnChange= (e) => {
        console.log('handleOnChange')
        setText(e.target.value)
    }
    return (
        <div>
    <div className="mb-3 mt-3">
        <h4 forhtml="myBox" className="form-label">{props.heading} - {text}</h4>
        <textarea onChange={handleOnChange} className="form-control" id="myBox" rows="8" value={text}></textarea>
        <input onClick={handleOnClick} type="submit" value="Convert to uppercase" className='btn btn-dark mt-3' />
    </div></div>
    )
}
