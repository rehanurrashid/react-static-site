import Navbar from './components/Navbar';

import { BrowserRouter as Router, Switch } from 'react-router-dom';
import AppRoutes from './routes'; // Import your routes


function App() {
  return (
    <>
    <Router>
      <Navbar title="Vedo" />  {/* Render Navbar */}
      <AppRoutes />  {/* Render routes */}
    </Router>

    </>
  );
}

export default App;
