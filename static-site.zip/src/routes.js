// src/routes.js
import React from 'react';
import { Route, Routes } from 'react-router-dom';  // Import Routes and Route

// Import your components for different routes
import TextForms from './views/TextForms';
import Contact from './views/Contact';
import HomePage from './views/HomePage'; // Assuming you have a HomePage component

const AppRoutes = () => {
  return (
    <Routes>
      {/* Define your Routes here */}
      <Route path="/" element={<HomePage />} />
      <Route path="/form" element={<TextForms />} />
      <Route path="/about" element={<Contact />} />
    </Routes>
  );
};

export default AppRoutes;
